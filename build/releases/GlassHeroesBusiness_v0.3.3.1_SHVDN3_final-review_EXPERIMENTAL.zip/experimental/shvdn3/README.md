# v0.3.3.1 SHVDN3 FINAL economy, pallets and wages — EXPERIMENTAL

CURRENT final review head: `experimental/shvdn3-economy-pallets-wages-review`. Linear stack: #27 repair coverage first, #25 manual sales second, separate nine-box pallet placement and manager wage action, isolated accepted-quote reload correction, final bounded pallet-refresh correction. No merges; main/QA R2/development/PR #21 foundation and original v2 sources/project unchanged. Manager supplier automation and forensic/blip work excluded.

`Install/scripts/GlassHeroesBusiness.3.cs` is the ONE installation source. The separate net48/C#7.3 `VisualStudio/GlassHeroesBusiness.V3.Experimental.csproj` links it directly and pins official ScriptHookVDotNet3 3.6.0. Installed Enhanced 3.9.0.6 compatibility NOT VERIFIED.

Read the [CURRENT final guide](../../docs/releases/v0.3.3.1-shvdn3-final-review/DEVELOPER_GUIDE.md), [review handoff](../../docs/releases/v0.3.3.1-shvdn3-final-review/REVIEW_HANDOFF.md), matching Word/PDF and recorded validation. Historical focused guides/packages retain their own source hashes and are superseded where the current guide says so. The [Phase 1 API map](../../docs/releases/v0.3.3.1-shvdn3-phase1/API_MAP.md) describes the foundation.

Accepted quotes, allocations and remaining active work persist in a bounded additive journal with atomic settlement. Keep source and full matching data backup together: older builds ignore pending journals; changing finances/stock there can intentionally block stale replay on return. Follow rollback/failure instructions; do not delete keys or mix financial snapshots.

GTA testing NOT RUN; Windows execution NOT RUN; crash cause UNATTRIBUTED / UNPROVEN. Tests use deterministic world/INI stubs. Review before any owner-authorized test. Never run duplicate/v2+v3 Business Manager scripts or replace installed SHVDN runtime files. Packages contain no live Save.ini, Settings.ini, active v2 source or runtime DLL. No installation, protected-branch push or merge occurred.
